The compile process is invoked by typing 'java Semantics file.cl' in the terminal

A log of the compile process is written to log.txt

This particular version of Clite has the following attributes:
 * Statically typed
 * Implicit widening for type conversions is allowed.
 * Explicit conversions are also allowed
 * Assignment statements use := rather than =
