// a first program with
// two comment lines
int main() {
    char c;
    int i;
    c := 'h';
    i := int(c) + 3;
} // main
